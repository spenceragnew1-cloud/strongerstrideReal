import { ArrowRight, CheckCircle, Zap } from 'lucide-react';

type Page = 'home' | 'assessment' | 'programs' | 'blog' | 'blog-post' | 'results';

interface HomeProps {
  onNavigate: (page: Page) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  return (
    <div className="bg-white">
      <section className="max-w-6xl mx-auto px-4 py-20 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-5xl sm:text-6xl font-bold text-slate-900 mb-6">
            Run Strong, Stay Healthy
          </h1>
          <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto">
            Evidence-based strength training designed specifically for runners. Identify your weaknesses and get a personalized 12-week program to prevent injuries and improve performance.
          </p>
          <button
            onClick={() => onNavigate('assessment')}
            className="inline-flex items-center gap-2 bg-green-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors shadow-lg shadow-green-500/30"
          >
            Start Free Assessment <ArrowRight className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-slate-50 p-8 rounded-xl border border-slate-200">
            <div className="flex items-center justify-center w-12 h-12 bg-green-100 rounded-lg mb-4">
              <Zap className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-3">10-Minute Assessment</h3>
            <p className="text-slate-600">
              Evidence-based movement tests that identify your specific strength, mobility, and stability gaps.
            </p>
          </div>

          <div className="bg-slate-50 p-8 rounded-xl border border-slate-200">
            <div className="flex items-center justify-center w-12 h-12 bg-green-100 rounded-lg mb-4">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-3">Personalized Programs</h3>
            <p className="text-slate-600">
              Get a tailored 12-week strength plan built around YOUR deficits, not generic workout.
            </p>
          </div>

          <div className="bg-slate-50 p-8 rounded-xl border border-slate-200">
            <div className="flex items-center justify-center w-12 h-12 bg-green-100 rounded-lg mb-4">
              <ArrowRight className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-3">Injury Prevention</h3>
            <p className="text-slate-600">
              Address weaknesses before they become injuries. Built on PubMed research and proven coaching.
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-50 to-slate-50 rounded-2xl p-12 border border-green-200">
          <div className="max-w-3xl">
            <h2 className="text-3xl font-bold text-slate-900 mb-6">Why Runners Need Strength Training</h2>
            <ul className="space-y-4 text-slate-700 mb-8">
              <li className="flex gap-3">
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                <span><strong>Prevents injuries:</strong> Weak stabilizers lead to compensation patterns that cause knee pain, IT band syndrome, and plantar fasciitis.</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                <span><strong>Improves running economy:</strong> Stronger muscles require less energy to maintain speed and form.</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                <span><strong>Boosts performance:</strong> More power from hips and ankles means faster sprint times and better pace control.</span>
              </li>
              <li className="flex gap-3">
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                <span><strong>Increases longevity:</strong> Balanced strength keeps you healthy year-round so you never miss training.</span>
              </li>
            </ul>
            <p className="text-slate-600 italic">
              "Most running injuries aren't caused by running too much—they're caused by doing too little else. Stronger Stride solves that."
            </p>
          </div>
        </div>

        <div className="mt-16 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Ready to get stronger?</h2>
          <p className="text-lg text-slate-600 mb-8">Complete the free movement assessment in 10 minutes and discover what's holding back your running.</p>
          <button
            onClick={() => onNavigate('assessment')}
            className="inline-flex items-center gap-2 bg-green-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors shadow-lg shadow-green-500/30"
          >
            Start Assessment Now <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>
    </div>
  );
}
