import { useEffect, useState } from 'react';
import { supabase, BlogPost } from '../lib/supabase';
import { ArrowLeft, Calendar, User } from 'lucide-react';

type Page = 'home' | 'assessment' | 'programs' | 'blog' | 'blog-post' | 'results';

interface BlogPostProps {
  slug: string;
  onNavigate: (page: Page) => void;
}

export default function BlogPostPage({ slug, onNavigate }: BlogPostProps) {
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    const loadPost = async () => {
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('slug', slug)
        .eq('is_published', true)
        .maybeSingle();

      if (error) {
        console.error('Error loading post:', error);
        setNotFound(true);
      } else if (!data) {
        setNotFound(true);
      } else {
        setPost(data);
      }
      setLoading(false);
    };

    loadPost();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-green-200 border-t-green-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Loading post...</p>
        </div>
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-slate-50">
        <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
          <button
            onClick={() => onNavigate('blog')}
            className="inline-flex items-center gap-2 text-green-600 font-semibold hover:text-green-700 mb-8 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" /> Back to Blog
          </button>
          <div className="bg-white rounded-xl shadow-lg p-12 text-center">
            <p className="text-slate-600 mb-6">Post not found.</p>
            <button
              onClick={() => onNavigate('blog')}
              className="inline-block bg-green-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-green-700 transition-colors"
            >
              Back to Blog
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!post) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-slate-50">
      <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <button
          onClick={() => onNavigate('blog')}
          className="inline-flex items-center gap-2 text-blue-600 font-semibold hover:text-blue-700 mb-8 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" /> Back to Blog
        </button>

        <article className="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200">
          {post.featured_image_url && (
            <img
              src={post.featured_image_url}
              alt={post.title}
              className="w-full h-96 object-cover"
            />
          )}

          <div className="p-8 md:p-12">
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">{post.title}</h1>

            <div className="flex flex-wrap items-center gap-6 text-slate-600 mb-8 pb-8 border-b border-slate-200">
              {post.published_at && (
                <div className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-green-600" />
                  <time dateTime={post.published_at}>
                    {new Date(post.published_at).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric',
                    })}
                  </time>
                </div>
              )}
              <div className="flex items-center gap-2">
                <User className="w-5 h-5 text-green-600" />
                <span>{post.author}</span>
              </div>
            </div>

            <div className="prose prose-sm md:prose-base lg:prose-lg max-w-none mb-8">
              <div className="text-slate-700 leading-relaxed whitespace-pre-wrap">
                {post.content}
              </div>
            </div>

            {post.seo_keywords && (
              <div className="bg-green-50 rounded-lg p-6 border border-green-200">
                <h3 className="font-semibold text-slate-900 mb-3">Topics:</h3>
                <div className="flex flex-wrap gap-2">
                  {post.seo_keywords.split(',').map((keyword, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-medium"
                    >
                      {keyword.trim()}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </article>

        <div className="mt-12 bg-green-50 rounded-xl p-8 border border-green-200">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">Ready to strengthen your running?</h2>
          <p className="text-slate-700 mb-6">
            Take the free movement assessment to identify your specific deficits and get a personalized strength program.
          </p>
          <button
            onClick={() => onNavigate('assessment')}
            className="inline-block bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
          >
            Start Free Assessment
          </button>
        </div>
      </div>
    </div>
  );
}
